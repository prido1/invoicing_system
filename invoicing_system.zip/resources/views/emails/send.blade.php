<html>
<head></head>
<body>
<div style="display: flex">
    <img style="width: 100px" src="{{asset('logo.png')}}">
    <h1 style="color: green">Chiminya <span style="color: red">logistics</span></h1>
</div>
{!! $title !!}
{!! $content !!}
</body>
</html>

